(function () {
    let skipLeft = 10; 
    let skipRight = 10; 

    chrome.storage.sync.get({ skipLeft: 10, skipRight: 10 }, (result) => {
        skipLeft = result.skipLeft;
        skipRight = result.skipRight;
    });

    function findPlayerContainer() {
        return document.querySelector('.html5-video-player') || document.querySelector('#movie_player');
    }

    function createButton(side, seconds) {
        const btn = document.createElement('button');
        btn.className = 'yt-10s-skip-button ' + side;
        btn.style.height = 'calc(100% - 200px)';
        btn.style.width = '60px';
        btn.style.pointerEvents = 'auto';
        btn.style.position = 'absolute';
        btn.style.background = 'transparent';
        btn.style.border = 'none';
        btn.style.cursor = 'pointer';

        const inner = document.createElement('div');
        inner.style.position = 'absolute';
        inner.style.top = '50%';
        inner.style.left = '50%';
        inner.style.transform = 'translate(-50%, -50%)';
        inner.style.display = 'flex';
        inner.style.flexDirection = 'column';
        inner.style.alignItems = 'center';
        inner.style.pointerEvents = 'none';
        btn.appendChild(inner);

        const icon = document.createElement('span');
        icon.innerText = side === 'left' ? '↺' : '↻';
        icon.style.fontSize = '30px';
        icon.style.color = '#fff';
        icon.style.opacity = '0';
        icon.style.transition = 'opacity 0.3s, transform 0.3s';
        inner.appendChild(icon);

        const text = document.createElement('span');
        text.innerText = side === 'left' ? `-${seconds}s` : `+${seconds}s`;
        text.style.fontSize = '16px';
        text.style.color = '#fff';
        text.style.opacity = '0';
        text.style.transition = 'opacity 0.3s';
        inner.appendChild(text);

        btn.addEventListener('mouseenter', () => {
            icon.style.opacity = '0.6';
            text.style.opacity = '0.6';
            icon.style.transform = side === 'left' ? 'rotate(-50deg)' : 'rotate(50deg)';
        });

        btn.addEventListener('mouseleave', () => {
            icon.style.opacity = '0';
            text.style.opacity = '0';
            icon.style.transform = 'rotate(0deg)';
        });

        btn.addEventListener('click', (e) => {
            e.stopPropagation();
            const video = document.querySelector('video');
            if (!video) return;
            if (side === 'left') {
                video.currentTime = Math.max(0, video.currentTime - seconds);
            } else {
                video.currentTime = Math.min(video.duration || Infinity, video.currentTime + seconds);
            }
        });

        btn.onmousedown = (ev) => ev.stopPropagation();

        return btn;
    }

    function injectUI(skipLeft, skipRight) {
        if (document.getElementById('yt-10s-skip-container')) return;
        const player = findPlayerContainer();
        if (!player) return;

        const container = document.createElement('div');
        container.id = 'yt-10s-skip-container';
        container.style.position = 'absolute';
        container.style.top = '0';
        container.style.left = '0';
        container.style.width = '100%';
        container.style.height = '100%';
        container.style.pointerEvents = 'none';
        container.style.zIndex = '9999';

        const leftBtn = createButton('left', skipLeft);
        leftBtn.style.left = '0';
        const rightBtn = createButton('right', skipRight);
        rightBtn.style.right = '0';

        container.appendChild(leftBtn);
        container.appendChild(rightBtn);

        if (getComputedStyle(player).position === 'static') {
            player.style.position = 'relative';
        }

        player.appendChild(container);
    }

    chrome.storage.sync.get({ skipLeft: 10, skipRight: 10 }, ({ skipLeft, skipRight }) => {
        injectUI(skipLeft, skipRight);
    });

    const observer = new MutationObserver(() => {
        const player = findPlayerContainer();
        if (player && !document.getElementById('yt-10s-skip-container')) {
            chrome.storage.sync.get({ skipLeft: 10, skipRight: 10 }, ({ skipLeft, skipRight }) => {
                injectUI(skipLeft, skipRight);
            });
        }
    });
    observer.observe(document.documentElement, { childList: true, subtree: true });

    window.addEventListener('yt-navigate-finish', () => {
        chrome.storage.sync.get({ skipLeft: 10, skipRight: 10 }, ({ skipLeft, skipRight }) => {
            injectUI(skipLeft, skipRight);
        });
    });

})();
