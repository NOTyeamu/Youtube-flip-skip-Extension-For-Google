document.addEventListener('DOMContentLoaded', () => {
    const leftInput = document.getElementById('leftSeconds');
    const rightInput = document.getElementById('rightSeconds');
    const saveBtn = document.getElementById('saveBtn');

    chrome.storage.sync.get({ skipLeft: 10, skipRight: 10 }, ({ skipLeft, skipRight }) => {
        leftInput.value = skipLeft;
        rightInput.value = skipRight;
    });

    saveBtn.addEventListener('click', () => {
        let leftVal = parseInt(leftInput.value) || 10;
        let rightVal = parseInt(rightInput.value) || 10;

        chrome.storage.sync.set({ skipLeft: leftVal, skipRight: rightVal }, () => {
            chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
                if (tabs[0]) chrome.tabs.reload(tabs[0].id);
            });
        });
    });
});
